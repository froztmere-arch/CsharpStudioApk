# C# Studio (APK) – Roslyn C# 14 compiler running inside the app

The editor, the C# compiler (Microsoft Roslyn 5.9) and the .NET 10 runtime (WebAssembly) all live inside the APK. The compiler uses the latest language version exposed by Roslyn (C# 14 with this package/runtime generation).
No server, no Termux, no internet after install.

## Build the APK (GitHub Actions)
1. Create a new GitHub repository.
2. Upload everything in this folder, **including the hidden `.github` folder** (easiest from a desktop browser: Add file > Upload files, or use git).
3. Open the Actions tab > "Build APK" > Run workflow (it also runs on every push to `main`).
4. When it is green, open the run and download the artifact `csharp-studio-apk`. Unzip it and install `app-debug.apk` (allow "install unknown apps").
If a step fails, send me the failing step's log and I will fix that step.

## First launch
- Status line shows "Loading compiler…" then "Ready · Roslyn … · .NET …". The first load and the first Run are slow on a Helio A22 (parsing Roslyn). Later runs are faster.
- Smoke tests to try, in order: the Hello World template (expect `Hello, World!` and `30`), a missing `;` (expect CS1002 with a Problems card), `int n = "hello";` inside Main (expect CS0029), `10 / zero` (expect a DivideByZeroException on stderr), the User input template, `dynamic value = 12; Console.WriteLine(value);`, an `unsafe` local-pointer example, records/primary constructors, and C# 14 syntax that does not require APIs missing from .NET 10.

## What is real
Source is compiled by Roslyn 5.9 (latest language version, C# 14, with .NET 10 framework references) on every Run and the resulting assembly is executed in the app. Errors and warnings are Roslyn's own. The framework reference table is cached after its first load; user source is recompiled on every run.

## Known limitations (honest list)
- Single-threaded execution: an infinite loop can freeze the app (there is no safe Stop button in this WebAssembly architecture). Your code is saved as a draft before every run, so force-close and reopen.
- `Console.ReadLine()` reads text typed in the Input tab beforehand, not live. At the end of that text it returns null.
- No supported multithreading or NuGet restore. Only framework assemblies shipped with the app are available. Basic file/network APIs may compile, but WebAssembly/browser sandbox limitations mean they are not equivalent to a desktop .NET runtime. Async/await and Task.Delay work.
- No implicit usings for user programs: add `using System;` like classic C#. The compiler now loads available `System.*` and `Microsoft.*` framework assemblies as metadata references, including namespaces such as `Microsoft.Extensions.*` when those assemblies ship in the app. A reference being available at compile time does not guarantee its APIs can run inside WebAssembly.
- Needs a recent Android System WebView (Chrome 91+). Memory is tight on 2 GB; the manifest requests a large heap, but out-of-memory crashes are possible.
- The compiler wasm is not AOT-compiled, so it runs interpreted and may be slow on older phones.
- The source package still needs a successful GitHub Actions build and on-device smoke tests. A successful build alone does not prove every language feature or runtime API works in the WebView sandbox.
- Missing from the UI: word wrap, multiple files, formatter, offline C# reference, and persistent output history. Error explanations cover common diagnostic codes; suggested fixes are intentionally limited and should be reviewed before applying.

## Review and reliability fixes in this revision
- Expanded compiler metadata references from only `System.*` to available `System.*` and `Microsoft.*` framework assemblies, so more shipped framework namespaces resolve correctly.
- Validates saved theme and font-size preferences before applying them, so malformed browser storage cannot corrupt the editor appearance.
- Console copy now reports when clipboard access is unavailable instead of silently doing nothing.
- File opening now reports read errors and always resets the file picker, allowing the same file to be selected again.
- Code export now reports the result and safely cleans up the temporary download URL.
- Unsupported WebAssembly operations now produce a plain-language explanation instead of only a generic exception dump.

## Editing features
Auto-indent and bracket/quote pairing (work with Android keyboards), Tab and Shift+Tab on selected lines, comment toggle (// button or Ctrl+/), find / replace / replace all / go to line (magnifier button or Ctrl+F, Ctrl+H, Ctrl+G), undo/redo, symbol toolbar, three themes, font size. Files over ~30,000 characters only color the visible part so typing stays fast.

## Performance notes
The compiler keeps one warm Roslyn compilation, so the first Run is slow and later Runs are faster. Parallel compile is switched off because the WebAssembly runtime has one thread.
