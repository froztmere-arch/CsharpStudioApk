using System.Diagnostics;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Loader;
using System.Text.Json;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.JSInterop;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
Studio.Http = new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) };
await builder.Build().RunAsync();

public static class Studio
{
    public static HttpClient Http;
    static List<MetadataReference> refs;
    static CSharpCompilation baseComp;
    static Task loading;
    static int counter;
    // Referenced so the linker/publisher always ships these framework assemblies.
    static readonly Type[] Keep = {
        typeof(Console), typeof(Enumerable), typeof(System.Text.RegularExpressions.Regex),
        typeof(System.Collections.Concurrent.ConcurrentDictionary<,>), typeof(System.Numerics.BigInteger),
        typeof(Microsoft.CSharp.RuntimeBinder.Binder) };
    // Common framework assemblies for the fallback path. Normally LoadRefs reads the
    // exact assembly inventory from blazor.boot.json instead of relying on this list.
    static readonly string[] Fallback = {
        "System.Private.CoreLib", "System.Runtime", "System.Console", "System.Collections",
        "System.Linq", "System.Threading", "System.Threading.Tasks", "System.Text.RegularExpressions",
        "System.Memory", "System.Runtime.Numerics", "System.Collections.Concurrent", "System.Runtime.Extensions",
        "System.Linq.Expressions", "System.ObjectModel", "System.ComponentModel", "System.Reflection",
        "System.Reflection.Extensions", "System.Runtime.InteropServices", "System.IO", "System.IO.FileSystem",
        "System.Net.Http", "System.Text.Json", "Microsoft.CSharp", "Microsoft.VisualBasic.Core", "netstandard", "mscorlib"
    };

    // Roslyn needs metadata references for every framework assembly a user's
    // program may import, not just System.*. The old filter excluded useful
    // framework namespaces such as Microsoft.Extensions.* and Microsoft.JSInterop.*,
    // which made valid types look "not supported" at compile time.
    static bool IsCompilerReference(string name)
    {
        if (!name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) ||
            name.EndsWith(".resources.dll", StringComparison.OrdinalIgnoreCase))
            return false;

        // Never reference the app entry assembly or Roslyn itself from user code.
        if (name.Equals("CSharpStudio.dll", StringComparison.OrdinalIgnoreCase) ||
            name.StartsWith("Microsoft.CodeAnalysis", StringComparison.OrdinalIgnoreCase))
            return false;

        return name.StartsWith("System.", StringComparison.OrdinalIgnoreCase) ||
               name.StartsWith("Microsoft.", StringComparison.OrdinalIgnoreCase) ||
               name.Equals("netstandard.dll", StringComparison.OrdinalIgnoreCase) ||
               name.Equals("mscorlib.dll", StringComparison.OrdinalIgnoreCase);
    }

    static async Task LoadRefs()
    {
        var names = new List<string>();
        try
        {
            using var doc = JsonDocument.Parse(await Http.GetStringAsync("_framework/blazor.boot.json"));
            foreach (var p in doc.RootElement.GetProperty("resources").GetProperty("assembly").EnumerateObject())
                if (IsCompilerReference(p.Name))
                    names.Add(p.Name);
        }
        catch { names = Fallback.Select(x => x + ".dll").ToList(); }
        var list = new List<MetadataReference>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var name in names)
        {
            if (!IsCompilerReference(name) || !seen.Add(name)) continue;
            try
            {
                var image = await Http.GetByteArrayAsync("_framework/" + name);
                list.Add(MetadataReference.CreateFromImage(ImmutableCollectionsMarshal.AsImmutableArray(image)));
            }
            catch
            {
                // Not every framework build ships every optional assembly in the fallback list.
            }
        }
        if (list.Count == 0) throw new Exception("No framework reference assemblies could be loaded.");
        refs = list;
    }

    [JSInvokable]
    public static string Info() =>
        $"Ready · Roslyn {typeof(CSharpCompilation).Assembly.GetName().Version} · {System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription}";

    [JSInvokable]
    public static async Task Warm() { try { await (loading ??= LoadRefs()); } catch { loading = null; baseComp = null; } }

    [JSInvokable]
    public static async Task<string> Run(string source, string stdin)
    {
        var res = new Dictionary<string, object>();
        try
        {
            try { await (loading ??= LoadRefs()); } catch { loading = null; baseComp = null; throw; }
            var sw = Stopwatch.StartNew();
            var tree = CSharpSyntaxTree.ParseText(source, new CSharpParseOptions(LanguageVersion.Latest), "Program.cs");
            // One shared base compilation keeps Roslyn's reference tables warm, so later runs are much faster.
            // concurrentBuild:false is required: the WebAssembly runtime has one thread and parallel compile would deadlock.
            baseComp ??= CSharpCompilation.Create("UserApp", null, refs,
                new CSharpCompilationOptions(
                    OutputKind.ConsoleApplication,
                    optimizationLevel: OptimizationLevel.Release,
                    concurrentBuild: false,
                    allowUnsafe: true));
            var comp = baseComp.AddSyntaxTrees(tree);
            using var ms = new MemoryStream();
            var emit = comp.Emit(ms);
            res["diags"] = emit.Diagnostics
                .Where(d => d.Severity >= DiagnosticSeverity.Warning && d.Id != "CS1701" && d.Id != "CS1702")
                .Select(d =>
                {
                    var p = d.Location.GetLineSpan().StartLinePosition;
                    return new { line = p.Line + 1, col = p.Character + 1, sev = d.Severity == DiagnosticSeverity.Error ? "error" : "warning", code = d.Id, msg = d.GetMessage() };
                }).ToList();
            res["built"] = emit.Success;
            res["buildMs"] = sw.ElapsedMilliseconds;
            if (!emit.Success) return JsonSerializer.Serialize(res);

            var asm = new AssemblyLoadContext("run" + (++counter)).LoadFromStream(new MemoryStream(ms.ToArray()));
            var entry = asm.EntryPoint;
            if (entry == null)
                throw new InvalidOperationException("The compiler produced no executable entry point.");

            var flags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
            // Async Main and async top-level statements can have a generated blocking wrapper.
            // Prefer Roslyn's Task-returning body when present to avoid blocking the single-threaded WASM runtime.
            var asyncBody = entry.DeclaringType?.GetMethods(flags).FirstOrDefault(m =>
                (m.Name == "<Main>" || m.Name == "<Main>$") && typeof(Task).IsAssignableFrom(m.ReturnType));
            if (asyncBody != null) entry = asyncBody;

            using var so = new LimitedStringWriter();
            using var se = new LimitedStringWriter();
            var oo = Console.Out; var oe = Console.Error; var oi = Console.In;
            Console.SetOut(so); Console.SetError(se); Console.SetIn(new StringReader(stdin ?? ""));
            int? code = 0;
            sw.Restart();
            try
            {
                var args = entry.GetParameters().Length == 0 ? null : new object[] { new string[0] };
                var r = entry.Invoke(null, args);
                if (r is Task t) { await t; r = t.GetType().GetProperty("Result")?.GetValue(t); }
                if (r is int i) code = i;
            }
            catch (Exception e)
            {
                var x = e is TargetInvocationException tie && tie.InnerException != null ? tie.InnerException : e;
                if (x is PlatformNotSupportedException || x is NotSupportedException)
                {
                    se.WriteLine("This API or operation is not supported by the app's .NET WebAssembly/browser runtime. " +
                                 "The C# compiler may accept the code, but desktop-only APIs, native OS access, " +
                                 "and multithreading are not available here.");
                    se.WriteLine(x.GetType().Name + ": " + x.Message);
                }
                else
                {
                    se.WriteLine("Unhandled exception. " + x);
                }
                code = null;
            }
            finally { Console.SetOut(oo); Console.SetError(oe); Console.SetIn(oi); }
            res["stdout"] = so.ToString();
            res["stderr"] = se.ToString();
            res["code"] = code;
            res["runMs"] = sw.ElapsedMilliseconds;
        }
        catch (Exception ex) { res["error"] = ex.GetType().Name + ": " + ex.Message; }
        return JsonSerializer.Serialize(res);
    }
}


// Limits captured output while it is being written, rather than allocating an
// unbounded StringWriter and truncating only after the program has finished.
public sealed class LimitedStringWriter : TextWriter
{
    const int MaxChars = 200_000;
    readonly System.Text.StringBuilder buffer = new();
    bool truncated;

    public override System.Text.Encoding Encoding => System.Text.Encoding.UTF8;

    void AppendLimited(string value)
    {
        if (string.IsNullOrEmpty(value)) return;
        var remaining = Math.Max(0, MaxChars - buffer.Length);
        if (remaining > 0) buffer.Append(value, 0, Math.Min(remaining, value.Length));
        if (value.Length > remaining) truncated = true;
    }

    public override void Write(char value) => AppendLimited(value.ToString());
    public override void Write(string value) => AppendLimited(value);
    public override void Write(char[] chars, int index, int count)
    {
        if (chars == null) throw new ArgumentNullException(nameof(chars));
        if (index < 0 || count < 0 || index > chars.Length - count) throw new ArgumentOutOfRangeException();
        var remaining = Math.Max(0, MaxChars - buffer.Length);
        if (remaining > 0) buffer.Append(chars, index, Math.Min(count, remaining));
        if (count > remaining) truncated = true;
    }

    public override Task WriteAsync(char value) { Write(value); return Task.CompletedTask; }
    public override Task WriteAsync(string value) { Write(value); return Task.CompletedTask; }
    public override Task WriteAsync(char[] chars, int index, int count) { Write(chars, index, count); return Task.CompletedTask; }

    public override string ToString() => buffer.ToString() +
        (truncated ? "\n[output truncated after 200,000 characters]" : string.Empty);
}
