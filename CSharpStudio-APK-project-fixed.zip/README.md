# C# Studio (APK) – real Roslyn C# compiler running inside the app

The editor, the C# compiler (Microsoft Roslyn) and the .NET runtime (WebAssembly) all live inside the APK.
No server, no Termux, no internet after install.

## Build the APK (GitHub Actions)
1. Create a new GitHub repository.
2. Upload everything in this folder, **including the hidden `.github` folder** (easiest from a desktop browser: Add file > Upload files, or use git).
3. Open the Actions tab > "Build APK" > Run workflow (it also runs on every push to `main`).
4. When it is green, open the run and download the artifact `csharp-studio-apk`. Unzip it and install `app-debug.apk` (allow "install unknown apps").
If a step fails, send me the failing step's log and I will fix that step.

## First launch
- Status line shows "Loading compiler…" then "Ready · Roslyn … · .NET …". The first load and the first Run are slow on a Helio A22 (parsing Roslyn). Later runs are faster.
- Smoke tests to try, in order: the Hello World template (expect `Hello, World!` and `30`), a missing `;` (expect error CS1002 with a Problems card), `int n = "hello";` inside Main (expect CS0029), `10 / zero` (expect an unhandled DivideByZeroException on stderr), the User input template with a name typed in the Input tab.

## What is real
Source is compiled by Roslyn (C# latest, .NET 8 references) on every Run and the resulting assembly is executed in the app. Errors and warnings are Roslyn's own. Nothing is cached between runs.

## Known limitations (honest list)
- Single thread: an infinite loop freezes the app (no Stop). Your code is saved as a draft before every run, so force-close and reopen.
- `Console.ReadLine()` reads text typed in the Input tab beforehand, not live. At the end of that text it returns null.
- No threads, no file/network APIs, no NuGet packages; only the .NET 8 framework libraries shipped in the app. Async/await and Task.Delay work.
- No implicit usings: add `using System;` like classic C#.
- Needs a recent Android System WebView (Chrome 91+). Memory is tight on 2 GB; the manifest requests a large heap, but out-of-memory crashes are possible.
- The compiler wasm is not AOT-compiled, so it runs interpreted and slowly on this phone.
- Not yet built or tested on a real device by me. Tests A–K from the original spec are unverified.
- Missing from the UI: word wrap, multiple files, formatter, offline C# reference, output history. Error explanations cover about eight common error codes; fix buttons only cover a missing `;` and a missing `using`.

## Editing features
Auto-indent and bracket/quote pairing (work with Android keyboards), Tab and Shift+Tab on selected lines, comment toggle (// button or Ctrl+/), find / replace / replace all / go to line (magnifier button or Ctrl+F, Ctrl+H, Ctrl+G), undo/redo, symbol toolbar, three themes, font size. Files over ~30,000 characters only color the visible part so typing stays fast.

## Performance notes
The compiler keeps one warm Roslyn compilation, so the first Run is slow and later Runs are faster. Parallel compile is switched off because the WebAssembly runtime has one thread.
